# Paleta de Cores — Login

## Azul Marinho
**Hex:** #002060

**Localização:**
- Fundo principal da tela de login
- Área de destaque da interface

---

## Branco
**Hex:** #FFFFFF

**Localização:**
- Card/formulário de login
- Textos sobre o fundo azul
- Campos e áreas claras da interface

---

## Cinza Claro
**Hex:** #F4F6F9

**Localização:**
- Fundo dos campos de entrada
- Elementos secundários da tela

---

## Cinza de Texto
**Hex:** #1E293B

**Localização:**
- Títulos
- Labels dos campos
- Textos informativos

---

## Vermelho
**Hex:** #C60014

**Localização:**
- Botão principal de acesso
- Elementos de destaque/alerta
