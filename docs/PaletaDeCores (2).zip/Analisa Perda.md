# Paleta de Cores — Analisa Perda

## Azul Marinho
**Hex:** #002060

**Localização:**
- Menu lateral esquerdo
- Cabeçalho
- Botões e elementos principais da página

---

## Vermelho
**Hex:** #C60014

**Localização:**
- Indicadores de perda
- Botões de ação
- Elementos de alerta

---

## Branco
**Hex:** #FFFFFF

**Localização:**
- Cards de análise
- Formulários
- Área principal de conteúdo

---

## Cinza Muito Claro
**Hex:** #F4F6F9

**Localização:**
- Fundo geral da página
- Área externa dos cards

---

## Cinza de Texto
**Hex:** #1E293B

**Localização:**
- Títulos
- Informações dos produtos
- Textos e labels

---

## Amarelo
**Hex:** #FFF9DB

**Localização:**
- Status de análise pendente
- Avisos e informações que exigem atenção
