# Paleta de Cores — Aprovar Perda

## Azul Marinho
**Hex:** #002060

**Localização:**
- Menu lateral esquerdo
- Cabeçalho
- Elementos principais da interface

---

## Vermelho
**Hex:** #C60014

**Localização:**
- Elementos relacionados às perdas
- Botões e ações de destaque
- Alertas

---

## Verde
**Hex:** #099268

**Localização:**
- Botão "Aprovar"
- Indicadores de aprovação

---

## Vermelho Claro
**Hex:** #E53935

**Localização:**
- Botão "Rejeitar"
- Ações de rejeição

---

## Branco
**Hex:** #FFFFFF

**Localização:**
- Cards
- Área principal
- Tabelas e componentes da página

---

## Cinza Muito Claro
**Hex:** #F4F6F9

**Localização:**
- Fundo geral da página
- Área externa dos cards

---

## Cinza de Texto
**Hex:** #1E293B

**Localização:**
- Títulos
- Informações das perdas
- Textos e labels

---

## Amarelo
**Hex:** #FFF9DB

**Localização:**
- Status "Pendente Aprovação"
- Indicadores de pendência
