# Paleta de Cores — Dashboard

## Azul Marinho
**Hex:** #002060

**Localização:**
- Menu lateral esquerdo
- Cabeçalho e elementos principais
- Botões e componentes de destaque

---

## Vermelho
**Hex:** #C60014

**Localização:**
- Item selecionado do menu
- Indicadores relacionados a perdas
- Alertas e ações de destaque

---

## Branco
**Hex:** #FFFFFF

**Localização:**
- Cards do dashboard
- Área principal de conteúdo
- Tabelas e componentes internos

---

## Cinza Muito Claro
**Hex:** #F4F6F9

**Localização:**
- Fundo geral da área de conteúdo
- Espaçamento ao redor dos cards

---

## Cinza de Texto
**Hex:** #1E293B

**Localização:**
- Títulos dos cards
- Textos e informações do dashboard
- Labels e descrições

---

## Amarelo
**Hex:** #FFF9DB

**Localização:**
- Indicadores de pendência
- Status que precisam de atenção
